package com.example.touch_me.pfe_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class LaunchScreen extends AppCompatActivity {

  TextView tvNewUser, tvTest;
  Button btnLogIn, btnSignUp;


  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_launch_screen);

    tvNewUser = (TextView) findViewById(R.id.tvNewUser);
    btnLogIn = (Button) findViewById(R.id.btnLogIn);
    btnSignUp = (Button) findViewById(R.id.btnSignUp);
    tvTest = (TextView) findViewById(R.id.tvTest);

    btnLogIn.setOnClickListener(new View.OnClickListener(){

      @Override
      public void onClick(View v) {
        loginMeth(v);
      }
    });
    btnSignUp.setOnClickListener(new View.OnClickListener(){

      @Override
      public void onClick(View v) {
        signupMeth(v);
      }
    });
  }

  public void loginMeth(View view){
    startActivity(new Intent(LaunchScreen.this, LoginAct.class));
  }
  public void signupMeth(View v){

  }
}
